from .mobilenet import *
from .resnet import *
from .vgg import *
from .magc_resnet import *
from .zoo import *
